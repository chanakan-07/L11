from django.shortcuts import render
from .models import Person

def index(request):
    data = Person.objects.all()
    return render(request, 'index.html', {'data': data})